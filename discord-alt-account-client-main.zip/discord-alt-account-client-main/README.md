# discord-alt-account-client
with this source code u will abel to join ur tokens (accounts without email) to voice channel or just make account online.

# HOW TO INSTALL :
 clone the project to repl or glitch (ill put the repl fork link down below).

 Install = (npm i express).

# set up : 
 make an env file (.env) and put ur tokens / Example ( token_1=" your first toekn " ).

 If you want the tokens to enter the voice channel just put your voice id in (config.json) file and make sure the tokens have role to join.

 If you set true for (setSelfDeaf) it will be deafen / false for the opposite is the same.
 
 If you set true for (setSelfMute) it will be mute / false for the opposite is the same.
 
 If you want to set game activity just put some game name in { name: '' }.
 
 change the status in (status: '') / all status in discord (dnd.idle.online.invisible) 
 
 this source works only for 24 tokens
 
# if u have any question dm me in discord : ੴ viki ριЖιs#6080 / GOOD LUCK
